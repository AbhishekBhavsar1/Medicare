package com.akash;

import org.springframework.data.jpa.repository.JpaRepository;

public interface medicineRepo extends JpaRepository<medicine, Integer> {

}
