package com.akash;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BuyRepo extends JpaRepository<Buy, Integer> {

}
